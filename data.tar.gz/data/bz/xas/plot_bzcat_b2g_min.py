import sys
import numpy as np
import matplotlib.pyplot as plt
import time
from scipy.interpolate import spline
from pylab import *
from scipy.interpolate import interp1d

x1shift = -0.7#-
x11shift = -0.7#-
x2shift = -0.7#-
x22shift = -0.7#-
xdummy = 0  
ydummy = 0 

#
data12 = np.genfromtxt('rohf_bz_cat_b3g_at_b2g.out.txt')
#ip12 = 2912.85
stcksx12 = data12[:,0] 
stcksy12 = (data12[:,1])
data12 = np.genfromtxt('rohf_bz_cat_b3g_at_b2g.out.dat')
x12 = data12[:,0] 
y12 = (data12[:,1])

#
data23 = np.genfromtxt('rohf_bz_cat_b2g_rel.txt')
#ip23 = 291.90
stcksx23 = data23[:,0] 
stcksy23 = (data23[:,1])
data23 = np.genfromtxt('rohf_bz_cat_b2g_rel.dat')
x23 = data23[:,0] 
y23 = (data23[:,1])

#Experiment
data5 = np.genfromtxt('bzcat_exp.csv')
ip5 = 291.10
x5 = data5[:,0] 
y5 = (data5[:,1])
#x5new = np.linspace(x5.min(),x5.max(),500) #300 represents number of points to make between T.min and T.maxy5new = spline(x5,y5,x5new)f = interp1d(x5, y5, kind='slinear')
#y5new = f(x5new)

params = {'mathtext.default': 'regular' }          
plt.rcParams.update(params)

f, (ax1, ax2) = plt.subplots(2, sharex=True, sharey=True)


plt.xlim(276,290) 
yip = 0.25
plt.xlabel('Excitation energy (eV)')
plt.ylabel('                                               Intensity (arb. units)')
plt.ylim(-0.02,yip) 
#plt.yticks([])

#plt.plot(x1+x1shift, y1, 'crimson', label='Non-planar geometry ( %.2f eV)' %x1shift, linewidth=2)#, linestyle='--')
#plt.set_title('Neutral geometry')
#plt.plot(x1+x1shift, y1, 'crimson', label='Bz', linewidth=2)#, linestyle='--')

ax1.plot(x12+x11shift, y12, '#006400', label='Bz$^+$ (B$_{3g}$) @ B$_{2g(min)}$', linewidth=2)#, linestyle='--')
ax1.plot(x23+x22shift, y23, '#669F66', label='Bz$^+$ (B$_{2g}$) @ B$_{2g(min)}$', linewidth=2)#, linestyle='--')

ax2.plot(x5, y5, 'k', label='Experiment', linewidth=2)#, linestyle='--')

ax1.plot(xdummy, ydummy, 'white',      label='$\Delta x$ = %.2f eV' %x1shift, linewidth=2)
ax1.legend(loc='upper left',fontsize='small', framealpha=1)
ax2.legend(loc='upper left',fontsize='small', framealpha=1)
#plt.plot([ip1+x1shift,ip1+x1shift],[0,yip],'crimson',linewidth=1.0, dashes=[5, 2])
#n=len(stcksx1)
#for i in range(n):
#    plt.plot([stcksx1[i]+x1shift,stcksx1[i]+x1shift],[0,stcksy1[i]*1],'crimson',linewidth=1.0)
#n=len(stcksx12)
#for i in range(n):
#    ax1.plot([stcksx12[i]+x11shift,stcksx12[i]+x11shift],[0,stcksy12[i]*1],'#006400',linewidth=1.0)
#n=len(stcksx23)
#for i in range(n):
#    ax1.plot([stcksx23[i]+x22shift,stcksx23[i]+x22shift],[0,stcksy23[i]*1],'#669F66',linewidth=1.0)

#ax1.text(280.5, stcksy23[0]+0.06, 'A', fontsize=12)
#ax1.text(283.9, stcksy23[1]+0.03, 'B ', fontsize=12)
#ax1.text(stcksx23[2]+x22shift-0.75, stcksy23[2]+0.06, 'C', fontsize=12)
#ax1.text(stcksx23[3]+x22shift+0.15, stcksy23[3]+0.06, 'D ', fontsize=12)
#ax1.text(stcksx23[4]+x22shift-0.15, stcksy23[4]+0.06, 'E ', fontsize=12)
#ax1.text(stcksx23[5]+x22shift, 0.02, 'F ', fontsize=12)
#ax1.text(288.8, 0.04, 'G ', fontsize=12)
#ax1.text(289.8, 0.1, 'H', fontsize=12)
#ax1.text(291, 0.06, 'I', fontsize=12)
#
#ax1.set_title('Cation geometry')
#n=len(stcksx2)
#for i in range(n):
#    ax1.plot([stcksx2[i]+x2shift,stcksx2[i]+x2shift],[0,stcksy2[i]*1],'crimson',linewidth=1.0)

#ax1.plot(x2+x2shift, y2, 'crimson', label='aug-cc-pVDZ', linewidth=2)#, linestyle='--')
#ax1.plot([ip2+x2shift,ip2+x2shift],[0,yip],'darkblue',linewidth=1.0, dashes=[5, 2])
#
#ax1.legend(loc='upper left',fontsize='small', framealpha=1)
#
#
#ax2.plot(x5, y5/4, 'black', label='Experiment' , linewidth=2 )
#ax2.plot([ip5,ip5],[0,yip],'black',linewidth=1.0, dashes=[5, 2])
#ax2.legend(loc='upper left',fontsize='small', framealpha=1)
#
f.subplots_adjust(hspace=0)
plt.setp([a.get_xticklabels() for a in f.axes[:-1]], visible=False)

plt.savefig('bzcat_at_b2g.pdf')
plt.show()
